#!/usr/bin/env bash
rake run:android:rhosimulator